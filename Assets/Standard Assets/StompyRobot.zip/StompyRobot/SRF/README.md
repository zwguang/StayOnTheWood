SRF (Stompy Robot Framework)
===

This is a stripped-down LITE version of SRF, containing the minimal necessary scripts for SRDebugger. Visit http://github.com/StompyRobot/SRF for the full version.


SRF contains numerious helpful behaviours and components for the Unity3D game engine that we use internally at Stompy Robot. We have made it available for anyone to use in their own games.

Dependencies
==
SRF depends on the following libraries, which are included in the External folder
* MiniJSON