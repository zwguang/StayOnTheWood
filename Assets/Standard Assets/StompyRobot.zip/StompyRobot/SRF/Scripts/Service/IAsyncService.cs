﻿namespace SRF.Service
{
    public interface IAsyncService
    {
        bool IsLoaded { get; }
    }
}
