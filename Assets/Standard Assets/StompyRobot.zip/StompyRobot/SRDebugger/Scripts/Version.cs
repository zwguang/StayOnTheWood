namespace SRDebugger {
    public static class VersionInfo {
        public const string Version = "1.12.1";
    }
}
