﻿namespace SRDebugger.UI.Other
{
    public interface IEnableTab
    {
        bool IsEnabled { get; }
    }
}
