﻿/*
 * This file has been moved to StoryRobot/SROptions/SROptions.cs
 * This empty file is left here to ensure it is properly overwritten when importing a new version of the package over an old version.
 */